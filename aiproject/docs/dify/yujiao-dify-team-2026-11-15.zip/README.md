# 粤教 Dify 组员联调包

2026-11-15 从本机 Dify 1.16.0 的已发布版本导出。解压后将 workflow 目录的 YAML 分别导入自己的 Dify 工作区。

| 文件 | 类型及节点数 | FastAPI 的密钥环境变量 |
| --- | --- | --- |
| cs.yml | 官网客服 Chatflow，36 节点 | CS_PUBLIC_DIFY_API_KEY |
| stu.yml | 学生助手 Chatflow，15 节点 | STU_DIFY_API_KEY |
| pf.yml | 客户研判 Workflow，8 节点 | PF_DIFY_API_KEY |
| rpt.yml | 员工正式报告 Workflow，4 节点 | DIFY_EMPLOYEE_FORMAL_API_KEY |
| ent.yml | 企业助手 Chatflow，32 节点 | DIFY_ENT_CHATFLOW_API_KEY |
| ent-portal-intent.yml | 企业门户备用 Workflow，3 节点 | DIFY_WORKFLOW_API_KEY |

客户研判的 8 节点版对应本机目前的发布版本。组员提交到代码仓库的 10 节点版及专用知识库，见 aiproject/docs/dify/local-integration 中的 pf.yml、pf-改动说明.md 和 pf-knowledge。联调时按所选版本配置 PF_DIFY_API_KEY。

## 导入与联调

1. 准备 Dify 1.16.0，安装并配置通义供应商。客服、学生助手和正式报告使用 qwen-plus，企业助手和备用工作流使用 qwen3.8-max。客服知识库的向量模型用 multimodal-embedding-v1。日报录音转写需要另在该工作区配置可用的默认语音转文字模型。
2. 导入前先建立下表的四个知识库。knowledge 下每个同名目录对应一个库，上传目录内的 TXT 文档。每个文件来自一条当前启用的知识分段。选择高质量索引和向量检索，确认文档完成索引。
3. 导入 cs.yml 后在四个知识检索节点各自选择对应的本地知识库。权重使用语义 100%、关键词 0%。如果工作区选择了其他嵌入模型，在检索节点同步设置模型。完成绑定后发布客服工作流。
4. 设置客服的 cs_api_base 和学生助手的 stu_api_base 为 Dify 容器能够访问的 FastAPI 地址。示例为 http://host.docker.internal:8003。Windows Docker Desktop 通常可用该主机名，其他环境按实际容器网络配置。学生助手的 stu_website_username 与 stu_website_password 留空，调用时由 FastAPI 传当前学生令牌。
5. 在各应用发布后，从「访问 API」分别创建自己的应用密钥。把这些密钥填入 aiproject/.env 或传给 FastAPI 进程的环境变量，再启动后端。DIFY_API_URL 填 FastAPI 能访问的 Dify 服务 API 基址，结尾带 /v1。目录中的 dify.env.example 列出配置项。
6. 启动最新版项目之前，按 aiproject/migrations/README.md 应用当前环境缺少的迁移。官网客服的连续会话需要 017，官网个人信息及头像需要 018。
7. 通过官网咨询德国或新加坡项目，登录后测试活动查询；通过学生页测试申请进度；通过员工工作台测试客户研判、正式报告和企业助手。日报录音转写默认复用企业助手的应用密钥，也可以为启用了转写的应用单独设置 DIFY_REPORT_TRANSCRIPTION_API_KEY。

| 客服节点 | 本地知识库名称 | 分段数 |
| --- | --- | --- |
| 公司信息快检索 | 粤教官网·公司简介 | 3 |
| FAQ 快检索 | 粤教官网·常见问题 | 7 |
| 业务项目检索 | 粤教官网·留学项目 | 12 |
| 留学政策检索 | 粤教官网·政策入口 | 4 |

应用密钥、供应商凭据和学生测试密码由各组员在自己的环境配置。内容仅包含联调用工作流与官网客服绑定的公开知识分段。
